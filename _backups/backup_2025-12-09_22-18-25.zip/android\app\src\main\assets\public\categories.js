// categories.js
// Liste centrale des catégories utilisées partout
const CATEGORIES = [
  "Logement",
  "Salaire",
  "Nourriture",
  "Transport",
  "Santé",
  "Loisirs",
  "Communication",
  "Internet",
  "Électricité",
  "Eau",
  "Épargne",
  "Investissements",
  "Éducation",
  "Vêtements",
  "Charges familiales",
  "Autre"
];
